package document_tagging;

public class IdfLoader {

}
