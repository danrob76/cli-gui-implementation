package document_tagging;

public @interface AllArgsConstructor {

}
