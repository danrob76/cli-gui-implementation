package capstone.documenttaggingsystem;

import org.junit.jupiter.api.Test;

public class FileParserTest {

    FileParser fileParser = new FileParser();

    /**
     * Verifies that the already-cleaned document is read correctly.
     */
    @Test
    public void testHappyPath(){
        assert ("this is only for testing purposes"
                .equals(fileParser.convertFileToAlphanumericString(
                        System.getProperty("user.dir") + "\\testDocuments\\testDocument1.txt\\"
                )));
    }

    /**
     * Verifies that non-alphanumerics are pruned and that the String is lowercased by the parser.
     */
    @Test
    public void testCleanedInput(){
        assert ("this is only for testing purposes"
                .equals(fileParser.convertFileToAlphanumericString(
                        System.getProperty("user.dir") + "\\testDocuments\\testDocument2.txt\\"
                )));
    }

    /**
     * Verifies that tabs and newlines are correctly translated to spaces.
     */
    @Test
    public void testWhitespaceParsing(){
        assert ("this is only for testing purposes"
                .equals(fileParser.convertFileToAlphanumericString(
                        System.getProperty("user.dir") + "\\testDocuments\\testDocument3.txt\\"
                )));
    }
}
