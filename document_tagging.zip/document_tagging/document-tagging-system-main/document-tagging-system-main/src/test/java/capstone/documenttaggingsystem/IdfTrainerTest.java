package capstone.documenttaggingsystem;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Map;

@ExtendWith(MockitoExtension.class)
public class IdfTrainerTest {

    @Mock
    FileParser fileParser;

    @InjectMocks
    IdfTrainer idfTrainer;

    /**
     * Tests that, if the FileParser returns the three test Strings when calls
     * are made to it, that it will train an Idf Map with the expected values.
     */
    @Test
    public void trainIdfMapHappyPath(){
        List<String> testStrings = TestUtils.generateTestStrings();

        Mockito.when(fileParser.convertFileToAlphanumericString(Mockito.anyString()))
                .thenReturn(testStrings.get(0))
                .thenReturn(testStrings.get(1))
                .thenReturn(testStrings.get(2));

        Map<String, Double> expected = TestUtils.generateIdfMap();

        idfTrainer.trainIdfMap(System.getProperty("user.dir") + "\\trainingData\\testSet1\\");

        Map<String, Double> actual = idfTrainer.getIdfMap();

        //For manually verifying the values this outputs
//        actual.forEach((key, value) -> System.out.println("Key: " + key + ", Value: " + value));

        Assertions.assertEquals(expected, actual);

    }


    //Uncomment this test and run it to generate the actual testIdfMap.txt file in the idfMaps directory
//    @Test
//    public void generateTestIdfMapFile(){
//        List<String> testStrings = TestUtils.generateTestStrings();
//
//        Mockito.when(fileParser.convertFileToAlphanumericString(Mockito.anyString()))
//                .thenReturn(testStrings.get(0))
//                .thenReturn(testStrings.get(1))
//                .thenReturn(testStrings.get(2));
//
//        idfTrainer.createIdfMap(
//                System.getProperty("user.dir") + "\\trainingData\\testSet1\\",
//                System.getProperty("user.dir") + "\\idfMaps\\testIdfMap.txt"
//        );
//    }

}
