module capstone.documenttaggingsystem {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires org.kordamp.bootstrapfx.core;

    requires static lombok;
    requires org.junit.jupiter.api;
    requires org.mockito;
    requires org.mockito.junit.jupiter;

    exports capstone.documenttaggingsystem;
    opens capstone.documenttaggingsystem to javafx.fxml;

}