package capstone.documenttaggingsystem;

import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * This class will receive a filepath directory, and using that, it will
 * open every .txt file in the directory, parse its contents using the
 * FileParser class, and combine all entries into an Idf Map.
 */
@RequiredArgsConstructor
@Data
public class IdfTrainer {

    Map<String, Double> idfMap = new HashMap<>();

    FileParser fileParser;

    final String DEFAULT_TRAINING_DIRECTORY = System.getProperty("user.dir") + "\\trainingData\\testSet1\\";

    /**
     * Trains an Idf Map given a directory for training data and a target
     * location to save the Idf Map.
     *
     * @param trainingDirectoryFilepath The directory to use as training data.
     * @param targetSaveFilepath The location to save the trained Idf Map.
     */
    public boolean createIdfMap(String trainingDirectoryFilepath, String targetSaveFilepath){

        //Defaults the training directory if given null
        trainingDirectoryFilepath = trainingDirectoryFilepath == null ? DEFAULT_TRAINING_DIRECTORY : trainingDirectoryFilepath;

        if(!trainIdfMap(trainingDirectoryFilepath)){
            return false;
        }
        if(!saveIdfMap(targetSaveFilepath)){
            return false;
        };

        return true;
    }

    /**
     * Saves the class's trained Idf Map to the target file location.
     *
     * @param targetSaveFilepath The filepath to save the class's Idf Map into.
     * @return Whether the operation was successful.
     */
    private boolean saveIdfMap(String targetSaveFilepath){

        //Verify the target filepath isn't already in use
        File file = new File(targetSaveFilepath);

        if(file.exists()){
            System.out.println("Specified Idf Map save filename already exists");
            return false;
        }

        //Save each entry in the Idf Map to a new line in target file,
        //separating key and value by comma
        try(BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(targetSaveFilepath))){
            for (Map.Entry<String, Double> entry : idfMap.entrySet()){
                bufferedWriter.write(entry.getKey() + "," + entry.getValue());
                bufferedWriter.newLine();
            }
        } catch (Exception e) {
            System.out.println("Error saving idf map");
            System.out.println(e.getMessage());
            return false;
        }

        return true;
    }

    /**
     * Trains the class's Idf Map on the files in the specified training
     * directory.
     *
     * @param trainingDirectoryFilepath The directory to use for training data.
     * @return Whether the operation was successful.
     */
    public boolean trainIdfMap(String trainingDirectoryFilepath){
        idfMap = new HashMap<>();
        double documentCount = 0;

        try{

            File trainingDirectory = new File(trainingDirectoryFilepath);

            //Verifies that the specified filepath is a directory
            if(trainingDirectory.isDirectory()) {

                File[] trainingFiles = trainingDirectory.listFiles();

                //Verifies the training directory isn't empty
                if(trainingFiles != null){

                    //Parses each file in the directory and splits it into its component words
                    for(File trainingFile : trainingFiles){
                        String parsedFile = fileParser.convertFileToAlphanumericString(trainingFile.getPath());
                        String[] words = parsedFile.split(" ");

                        //Flattens the array of words into a HashSet
                        Set<String> wordSet = new HashSet<>();

                        for(String word : words){
                            wordSet.add(word);
                        }

                        //Increments the Idf Map's entries for every occurrence of a word
                        for(String word : wordSet){
                            idfMap.put(word, idfMap.getOrDefault(word, 0.0) + 1);
                        }

                        //Keeps running count of how many files have been mapped
                        documentCount++;
                    }

                    //Converts each entry in the Idf Map from its current count to its Idf value
                    for(String word : idfMap.keySet()){
                        idfMap.put(word, Math.log(documentCount / idfMap.get(word)));
                    }

                } else {
                    System.out.println("Specified training directory is empty");
                    return false;
                }

            } else {
                System.out.println("Specified training directory isn't a directory");
                return false;
            }
        } catch (Exception e) {
            System.out.println("Error training the Idf Map");
            System.out.println(e.getMessage());
            return false;
        }

        return true;
    }
}
