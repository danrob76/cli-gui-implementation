package capstone.documenttaggingsystem;

import javafx.application.Application;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * This is the GUI for managing file selection for the
 * document tagging process.
 */

public class DocumentTaggingApplication extends Application {

    @Override
    public void start(Stage stage) throws IOException {

    }

//    public static void main(String[] args) {
//        launch();
//    }

    //This is just so you can quickly make sure your IDE, Gradle, and JDK versions are all playing nice.
    //Comment out/delete for actual development.
    public static void main(String[] args){
        System.out.println("Context runs!");
    }
}
